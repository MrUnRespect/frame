
module.exports = {
    data1: [
        {
            time: "2009年12月-2010年11月1",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        },
        {
            time: "2009年12月-2010年11月2",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        },
        {
            time: "2009年12月-2010年11月3",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        },
        {
            time: "2009年12月-2010年11月4",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        },
        {
            time: "2009年12月-2010年11月5",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        },
        {
            time: "2009年12月-2010年11月6",
            msg: "XXXXXXXXXXX单位      XXXXXXXX部门     任XXXXXXXXX"
        }
    ]


}

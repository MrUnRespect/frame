module.exports = {
    data1: {
        boxTitle: [
            {
                name: "参与创新创业指导教师人数 ",
                num: "XXX人",
            },
            {
                name: "占比 ",
                num: "XXX%",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "XXX%"
            },
        ],
        data: [4,8,11,15,16],
        xAxis: ["2013","2014","2015","2016","2017"]
    },

}




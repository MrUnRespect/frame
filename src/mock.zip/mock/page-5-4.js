module.exports = {
    data1: {
        boxTitle: [
            {
                name: "参与培训进修 ",
                num: "XX人",
                name2: "占比",
                per: "XX%",
                name3: "同比",
                icon: "/static/assets/icon-reduce.png",
                tb: "XX%"
            }
        ],
        data: [4,8,11,15,16],
        xAxis: ["2013","2014","2015","2016","2017"]
    },
}




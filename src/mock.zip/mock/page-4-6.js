module.exports = {
    data1: {
        areaTitle: "承担教材建设项目",
        boxTitle: [
            {
                name: "人数",
                num: "XX",
                name2: "占比",
                per: "XX%",
                name3:"同比",
                icon: "/static/assets/icon-add.png",
                tb:"XX%"
            },
        ],
        time: ["2013", "2014", "2015", "2016", "2017"],
        data: ["123", "115", "121", "122", "136"],
    }
}




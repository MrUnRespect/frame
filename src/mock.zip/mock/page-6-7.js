module.exports = {
    data1: {
        areaTitle: "教师职业认同比例",
        boxTitle: [
            {
                num: "XX%",
                name2:"较去年",
                icon: "/static/assets/icon-add.png",
                tb: "XX%"
            },
        ],
        value: 50,
    },


}





module.exports = {
  data1: {
    data: [
      {
        value: 56,
        name: "A"
      },
      {
        value: 89,
        name: "B"
      },
      {
        value: 115,
        name: "C"
      },
      {
        value: 128,
        name: "D"
      }
    ],
    evaluate: "个人评价\n{a|B}"
  },
  data2: {
    data: [
      {
        value: 56,
        name: "A"
      },
      {
        value: 89,
        name: "B"
      },
      {
        value: 115,
        name: "C"
      },
      {
        value: 128,
        name: "D"
      }
    ],
    evaluate: "个人评价\n{a|B}"
  },
  data3: {
    data: [
      {
        value: 56,
        name: "A"
      },
      {
        value: 89,
        name: "B"
      },
    ],
    evaluate: "个人评价\n{a|B}"
  },
  data4: {
    data: [
      {
        value: 56,
        name: "A"
      },
      {
        value: 89,
        name: "B"
      },
      {
        value: 115,
        name: "C"
      },
      {
        value: 128,
        name: "D"
      }
    ],
    evaluate: "个人评价\n{a|A}"
  },
  data5: {
    xAxis: ["2013", "2014", "2015", "2016", "2017"],
    data: [
      {
        name: "班级管理1",
        value: [[20, 10], [30, 20], [10, 10], [0, 0], [25, 35]]
      },
      {
        name: "社团指导",
        value: [[30, 20], [10, 30], [10, 40], [40, 5], [25, 15]]
      },
      {
        name: "兼职服务",
        value: [[10, 40], [20, 30], [20, 40], [10, 30], [0, 10]]
      },
      {
        name: "社会兼职",
        value: [[33, 18], [16, 24], [19, 40], [12], [30, 30]]
      }
    ]
  }
}

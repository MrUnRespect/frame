
module.exports = {
    data1: {
        boxTitle: [
            {
                name: "发表论文 ",
                num: "XX篇",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "2%",

            },
            {
                name: "其中C级及以上 ",
                num: "XX篇",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "2%",

            },
        ],
        data: [
            {
                value: 56,
                name: "A"
            },
            {
                value: 89,
                name: "B"
            },
            {
                value: 115,
                name: "C"
            },
            {
                value: 128,
                name: "D"
            }
        ],

    },
    data2: {
        time: ["2013", "2014", "2015", "2016", "2017"],
        data: ["123", "115", "121", "122", "136"]
    }

}

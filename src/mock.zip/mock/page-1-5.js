
module.exports = {
    data1: {
        boxTitle: [
            {
                name: "男女性别比例",
                num: "XXX",
                name2: "较去年",
                icon: "/static/assets/icon-add.png",
                tb: "2%",
            },

        ],
        data: [
            { name: "男", data: [55, 45, 55, 65, 33] },
            { name: "女", data: [48, 42, 41, 55, 52] },

        ],
        yAxis: ['2017', '2016', '2015', '2014', '2013']
    },
}

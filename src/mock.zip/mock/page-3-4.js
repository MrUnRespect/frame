
module.exports = {

    data1: {
        boxTitle: [
            {
                name: "学术著作",
                num: "XX门",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "2%"
            },
            {
                name: "其中专著",
                num: "XX门",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "2%"
            },
            {
                name: "译著",
                num: "XX门",
                name2: "同比",
                icon: "/static/assets/icon-add.png",
                tb: "2%"
            },
        ],
        data: [
            {
                name: '专著1',
                value: [15, 16, 17, 17, 20]
            },
            {
                name: '译著',
                value: [26, 28, 30, 32, 34]
            }
        ]
    }
}


module.exports = {
    data1: [
        {
            time: "2010年11月",
            msg: "XXXXXX主持XXXXXXXXXXX；"
        },
        {
            time: "2010年11月",
            msg: "XXXXXX获奖XXXXXXXXXXX；"
        },
        {
            time: "2010年11月",
            msg: "XXXXXX担任XXXXXXXXXXX；"
        },
        {
            time: "2010年11月",
            msg: "XXXXXX提名XXXXXXXXXXX；"
        },
        {
            time: "2010年11月",
            msg: "XXXXXX主持XXXXXXXXXXX；"
        },
        {
            time: "2010年1月",
            msg: "XXXXXX获奖XXXXXXXXXXX；"
        },
        {
            time: "2010年11月",
            msg: "XXXXXX主持XXXXXXXXXXX；"
        },
        {
            time: "2010年11月8",
            msg: "XXXXXX提名XXXXXXXXXXX；"
        }
    ]


}

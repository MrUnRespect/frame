
module.exports = {
    data1: [
        {
            name: "调入1",
            value: 56,
            deep: true
        },
        {
            name: "总人数",
            value: 89,
            deep: false
        }
    ],
    data2: [
        {
            name: "调入2",
            value: 56,
            deep: true
        },
        {
            name: "总人数",
            value: 89,
            deep: false
        }
    ],
    data3: [
        {
            name: "调入3",
            value: 56,
            deep: true
        },
        {
            name: "总人数",
            value: 89,
            deep: false
        }
    ],
    data4: [
        {
            name: "调入4",
            value: 56,
            deep: true
        },
        {
            name: "总人数",
            value: 89,
            deep: false
        }
    ],
    data5: [
        {
            name: "调入5",
            value: 56,
            deep: true
        },
        {
            name: "总人数",
            value: 89,
            deep: false
        }
    ]
}
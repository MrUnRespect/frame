
module.exports = {
    data1: {
        name: "X",
        department: "XXXXX",
        account: "XXXXXXXXXXX",
        timeNow: "XXX",
        timeLast: "XXXX"
    }


}

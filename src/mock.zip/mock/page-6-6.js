module.exports = {
    data1: {
        boxTitle: [
            {
                name: "教师参与社会兼职人数 ",
                num: "XXX",
            },
            {
                name:"占比",
                num:"XX%",
                name2: " 同比",
                icon: "/static/assets/icon-add.png",
                tb: "XX%"
            }
        ],
        time: ["2013", "2014", "2015", "2016", "2017"],
        data: ["123", "115", "121", "122", "136"],
    },
    data2: {
        areaTitle: "教师参与不同级别社会兼职情况",
        data: [
            { name: "国家级", data: [55, 45, 55, 65, 33] },
            { name: "省部级", data: [48, 42, 41, 55, 52] },
            { name: "其他兼职", data: [69, 89, 32, 42, 45] },
        ],
        yAxis: ['2017', '2016', '2015', '2014', '2013'],
    }

}




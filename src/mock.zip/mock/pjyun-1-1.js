module.exports = {
  data1: [
    {
      name: '累计产生评价总数',
      value: 5274,
      unit: '万',
      icon: '/static/assets/pjyun/icon1.png'
    }, {
      name: '累计产生评价总数',
      value: 25866000,
      unit: '',
      icon: '/static/assets/pjyun/icon2.png'
    }, {
      name: '已开通家长数',
      value: 6653,
      unit: '',
      icon: '/static/assets/pjyun/icon3.png'
    }
  ]
}

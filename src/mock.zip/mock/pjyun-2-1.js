module.exports = {
  data1: [
    {
      school: '成华小学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'up'
      },
      studentday: 500,
      types: [true, true, true]
    },
    {
      school: '电子科技大学附属实验小学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'up'
      },
      studentday: 500,
      types: [false, true, true]
    },
    {
      school: '成都石室初中青龙校区',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'up'
      },
      studentday: 500,
      types: [true, false, true]
    },
    {
      school: '成都石室初中青龙校区',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'normal'
      },
      studentday: 500,
      types: [true, true, false]
    },
    {
      school: '成都石室初中青龙校区',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [false, false, true]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    },
    {
      school: '成华中学',
      patriarch: 5274,
      totalevaluation: 400,
      year: 5000,
      day: {
        value: 500,
        type: 'down'
      },
      studentday: 500,
      types: [true, false, false]
    }
  ]
}
